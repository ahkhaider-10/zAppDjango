from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from django.shortcuts import render, HttpResponse, redirect, HttpResponseRedirect
from datetime import datetime
from zAppDjango.models import Contact
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib.auth import logout, login

# Create your views here.


def index(request):
    if request.user.is_anonymous:
        return redirect("/login")
    return render(request, 'index.html')
    # return HttpResponse('HomePage')


def about(request):
    # return HttpResponse('AboutPage')
    return render(request, 'about.html')


def contact(request):
    # return HttpResponse('ContactPage')

    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        contact = Contact(name=name, email=email, phone=phone,
                          desc=desc, date=datetime.today())
        contact.save()
        messages.success(request, 'Your message has been sent.')
    return render(request, 'contact.html')


def loginUser(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect("/")
            # return render(request, 'login.html')
        else:
            # Show an error message to the user if the authentication failed.
            error_message = "Invalid username or password."
            return render(request, 'login.html', {'error_message': error_message})
    elif request.user.is_authenticated:
        # If the user is already authenticated, redirect them to the home page.
        return redirect("/")
        # return render(request, 'login.html')
    else:
        # Render the login form.
        return render(request, 'login.html')


def logoutUser(request):
    logout(request)
    return redirect('/login')
